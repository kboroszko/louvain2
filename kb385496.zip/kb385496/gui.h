//
// Created by kajetan on 08.05.2020.
//

#ifndef LOUVAIN2_GUI_H
#define LOUVAIN2_GUI_H

#endif //LOUVAIN2_GUI_H
